﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reg
{
    public partial class UserForm : Form
    {
        int a = 0;
        int b = 0;
        Random rand = new Random();
        public UserForm()
        {
            InitializeComponent();
            a = rand.Next(0, 100);
            b = rand.Next(0, 100);           
            pLB.Text = $"{a} + {b} = ";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {          
                if (answerTB.Text == (a + b).ToString())
                {
                    MessageBox.Show("Правильный ответ!!!", "Победа", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    a = rand.Next(0, 100);
                    b = rand.Next(0, 100);
                    pLB.Text = $"{a} + {b} = ";
                }
                else
                {
                   
                    MessageBox.Show("Неправильный ответ!", "Проигрыш", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }           
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

        }
    }
}
